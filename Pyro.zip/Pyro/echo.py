# creates the remote object
# will just send back the message you send it

#run me in terminal


import Pyro5

from Pyro5 import api

@Pyro5.api.expose
@Pyro5.api.behavior(instance_mode = "single")
class Echo:

    def ping(self,message):
        self.message = "Echo: "+message
        print(self.message)
        return self.message

def main():
    Pyro5.api.config.HOST = "192.168.10.2"
    Pyro5.api.Daemon.serveSimple(
        {
            Echo: "example"
        },
        ns=False)

if __name__ == "__main__":
    main()