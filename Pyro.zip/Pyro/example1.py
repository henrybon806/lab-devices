# calls the remote object
import Pyro5
from Pyro5 import api

#uri = input("Enter the uri of the object: ").strip()
uri = "PYRO:example@192.168.10.1:50333"

remoteEcho = Pyro5.api.Proxy(uri)
print(remoteEcho.ping("hello world"))

# PYRO:example@localhost:56306

# you should set the ip address of main computetr to 192.168.10.1 and others to ... 10.2, ...10.3 and so on

# Computer A
# netsh interface ip set address "Ethernet" static 192.168.10.1 255.255.255.0
#
# # Computer B
# netsh interface ip set address "Ethernet" static 192.168.10.2 255.255.255.0
#
# # Allow ping (ICMP) on both machines
# netsh advfirewall firewall add rule name="Allow ICMPv4-In" protocol=any dir=in action=allow