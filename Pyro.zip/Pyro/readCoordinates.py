from PIL import Image
# import easyocr
# import matplotlib.pyplot as plt
#import skimage as ski
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
import mss
from PIL import Image
import re

def main():
    with mss.MSS() as sct:
        
        region = {"left": 830, "top": 220, "width": 370, "height": 30}
        
        screenshot = sct.grab(region)

        Iroi = Image.frombytes("RGB", screenshot.size, screenshot.rgb)
        

    result = pytesseract.image_to_string(Iroi)
    #print(f"{result}")
    parts = result.split()
    xread = re.search(r"\d+",parts[2])
    #if fail to read try 3 more times
    tries = 0
    if not bool(xread):
        while tries < 3:
            xread = re.search(r"\d+",parts[2])
            if bool(not bool(xread)):
                break
            time.sleep(0.5)
            tries +=1
        
        if not bool(xread):
            raise ValueError("OCR Cannot read stage position")

    yread = re.search(r"\d+",parts[-1])
    coords = [int(xread[0]),int(yread[0])]
    return coords

if __name__ == "__main__":
    print(main())

#plt.imshow(Iroi)
#plt.show()