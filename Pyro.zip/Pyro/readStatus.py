from PIL import Image
import time
# import easyocr
# import matplotlib.pyplot as plt
#import skimage as ski
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
import mss
from PIL import Image
import re

def main():
    with mss.MSS() as sct:
        
        region = {"left": 1000, "top": 130, "width": 400, "height": 30}
        
        screenshot = sct.grab(region)

        Iroi = Image.frombytes("RGB", screenshot.size, screenshot.rgb)
        

    result = pytesseract.image_to_string(Iroi)
    #print(f"{result}")
    parts = result.split()
#     print(parts[0]=='Status:')
#     print(parts[1])
    return parts[1:]
    
if __name__ == "__main__":
        print(main())

#plt.imshow(Iroi)
#plt.show()
